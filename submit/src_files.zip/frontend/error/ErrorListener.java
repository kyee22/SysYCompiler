/*
 * SysYCompiler: A Compiler for SysY.
 *
 * SysYCompiler is an individually developed course project
 * for Compiling Techniques @ School of Computer Science &
 * Engineering, Beihang University, Fall 2024.
 *
 * Copyright (C) 2024 Yixuan Kuang <kyee22@buaa.edu.cn>
 *
 * This file is part of SysYCompiler.
 */

package frontend.error;

public interface ErrorListener {
    void onError(int lineno, ErrorType errorType);

    void onRollback(int lineno, ErrorType errorType);

    boolean hasErrors();

    void flushErrors(String errorFilePath);
}
