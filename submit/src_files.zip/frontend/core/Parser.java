/*
 * SysYCompiler: A Compiler for SysY.
 *
 * SysYCompiler is an individually developed course project
 * for Compiling Techniques @ School of Computer Science &
 * Engineering, Beihang University, Fall 2024.
 *
 * Copyright (C) 2024 Yixuan Kuang <kyee22@buaa.edu.cn>
 *
 * This file is part of SysYCompiler.
 */

package frontend.core;

import frontend.error.ErrorListener;
import frontend.error.ErrorType;
import frontend.sysy.context.*;
import frontend.sysy.token.Token;
import frontend.sysy.token.TokenType;

import static frontend.sysy.token.TokenType.*;
import static frontend.error.ErrorType.*;
import static utils.AssertUtils.ASSERT;

import java.util.*;

public class Parser {

    private final LinkedList<Token> tokens;
    private Token token = null;
    private ListIterator<Token> iterator = null;
    private List<ErrorListener> errorListeners = new ArrayList<>();
    private Context ast = null;

    public Parser(List<Token> tokens) {
        this.tokens = new LinkedList<>(tokens);
        iterator = tokens.listIterator();
    }

    /**     TODO
     *          lineno √
     *          EOFTK
     *
     *          1. 修改 assert
     *          2. 修改 可能空指针
     */

    public void engine() {
        ASSERT(iterator.hasNext(), "Got no token");
        token = iterator.next();
        ast = parseCompUnitContext();
    }

    public Context getAst() {
        return ast;
    }

    /**
     * 编译单元 CompUnit → {Decl} {FuncDef} MainFuncDef
     * compUnit    : (decl)* (funcDef)* mainFuncDef EOF
     *             ;
     */
    private CompUnitContext parseCompUnitContext() {
        CompUnitContext compUnit = new CompUnitContext();

        // buggy!!! `nextToken` & `nextnextToken` are static!!
        // they should dynamicly update as 'while' loop goes on!!!
        //Token nextToken = peekNext(iterator, tokens, 1);
        //Token nextnextToken = peekNext(iterator, tokens, 2);
        while ((token.is(CONSTTK))
                || (token.any(INTTK, CHARTK) && peekNext(1).is(IDENFR) && !peekNext(2).is(LPARENT))) {
            compUnit.add(parseDeclContext());
        }
        while (token.any(INTTK, CHARTK, VOIDTK) && peekNext(1).is(IDENFR) && peekNext(2).is(LPARENT)) {
            compUnit.add(parseFuncDefContext());
        }
        compUnit.add(parseMainFuncDefContext());
        ASSERT(!iterator.hasNext() && token == null, "Expected EOF");

        return compUnit;
    }

    /**
     * 声明 Decl → ConstDecl | VarDecl
     * decl        : constDecl
     *             | varDecl
     *             ;
     */
    private DeclContext parseDeclContext() {
        if (token.is(CONSTTK)) {
            return parseConstDeclContext();
        } else  {
            return parseVarDeclContext();
        }
    }

    /**
     * 常量声明 ConstDecl → 'const' BType ConstDef { ',' ConstDef } ';'
     * constDecl   : CONST bType constDef (COMMA constDef)* SEMICOLON
     *             ;
     */
    private ConstDeclContext parseConstDeclContext() {
        ConstDeclContext constDecl = new ConstDeclContext();

        constDecl.add(match(CONSTTK));
        constDecl.add(parseBTypeContext());
        constDecl.add(parseConstDefContext());

        while (token.is(COMMA)) {
            constDecl.add(match(COMMA));
            constDecl.add(parseConstDefContext());
        }

        if (token.is(SEMICN)) {
            constDecl.add(match(SEMICN));
        } else {
            // error handle by CATCH
            notifyErrorListeners(constDecl.getEndLineno(), MISSING_SEMICOLON);
        }
        return constDecl;
    }

    private BTypeContext parseBTypeContext() {
        BTypeContext bType = new BTypeContext();

        bType.add(match(INTTK, CHARTK));

        return bType;
    }

    public ConstDefContext parseConstDefContext() {
        ConstDefContext constDef = new ConstDefContext();

        constDef.add(match(IDENFR));

        if (token.is(LBRACK)) {
            constDef.add(match(LBRACK));
            constDef.add(parseConstExpContext());
            if (token.is(RBRACK)) {
                constDef.add(match(RBRACK));
            } else {
                notifyErrorListeners(constDef.getEndLineno(), MISSING_RBRACK);
            }
        }

        constDef.add(match(ASSIGN));
        constDef.add(parseConstInitValContext());
        return constDef;
    }

    public ConstInitValContext parseConstInitValContext() {
        ConstInitValContext constInitVal = new ConstInitValContext();

        if (token.is(STRCON)) {
            constInitVal.add(match(STRCON));
        } else if (token.is(LBRACE)) {
            constInitVal.add(match(LBRACE));
            // 试探 constExp
            if (token.any(IDENFR, INTCON, CHRCON, LPARENT, PLUS, MINU, NOT)) {
                constInitVal.add(parseConstExpContext());
                while (token.is(COMMA)) {
                    constInitVal.add(match(COMMA));
                    constInitVal.add(parseConstExpContext());
                }
            }
            constInitVal.add(match(RBRACE));
        } else {
            constInitVal.add(parseConstExpContext());
        }

        return constInitVal;
    }

    /**
     * 变量声明 VarDecl → BType VarDef { ',' VarDef } ';'
     * varDecl     : bType varDef (COMMA varDef)* SEMICOLON
     *             ;
     */
    public VarDeclContext parseVarDeclContext() {
        VarDeclContext varDecl = new VarDeclContext();

        varDecl.add(parseBTypeContext());
        varDecl.add(parseVarDefContext());
        while (token.is(COMMA)) {
            varDecl.add(match(COMMA));
            varDecl.add(parseVarDefContext());
        }

        if (token.is(SEMICN)) {
            varDecl.add(match(SEMICN));
        } else {
            notifyErrorListeners(varDecl.getEndLineno(), MISSING_SEMICOLON);
        }

        return varDecl;
    }

    private VarDefContext parseVarDefContext() {
        VarDefContext varDef = new VarDefContext();

        varDef.add(match(IDENFR));
        if (token.is(LBRACK)) {
            varDef.add(match(LBRACK));
            varDef.add(parseConstExpContext());
            if (token.is(RBRACK)) {
                varDef.add(match(RBRACK));
            } else {
                notifyErrorListeners(varDef.getEndLineno(), MISSING_RBRACK);
            }
        }

        if (token.is(ASSIGN)) {
            varDef.add(match(ASSIGN));
            varDef.add(parseInitValContext());
        }

        return varDef;
    }

    private InitValContext parseInitValContext() {
        InitValContext initVal = new InitValContext();

        if (token.is(LBRACE)) {
            initVal.add(match(LBRACE));
            // 试探 exp
            if (token.any(IDENFR, INTCON, CHRCON, LPARENT, PLUS, MINU, NOT)) {
                initVal.add(parseExpContext());
                while (token.is(COMMA)) {
                    initVal.add(match(COMMA));
                    initVal.add(parseExpContext());
                }
            }
            initVal.add(match(RBRACE));
        } else if (token.is(STRCON)) {
            initVal.add(match(STRCON));
        } else {
            initVal.add(parseExpContext());
        }

        return initVal;
    }

    private FuncDefContext parseFuncDefContext() {
        FuncDefContext funcDef = new FuncDefContext();

        funcDef.add(parseFuncTypeContext());
        funcDef.add(match(IDENFR));
        funcDef.add(match(LPARENT));
        // 试探形参
        if (token.any(INTTK, CHARTK)) {
            funcDef.add(parseFuncFParamsContext());
        }
        if (token.is(RPARENT)) {
            funcDef.add(match(RPARENT));
        } else {
            notifyErrorListeners(funcDef.getEndLineno(), MISSING_RPARENT);
        }
        funcDef.add(parseBlockContext());

        return funcDef;
    }

    private MainFuncDefContext parseMainFuncDefContext() {
        MainFuncDefContext mainFuncDef = new MainFuncDefContext();

        mainFuncDef.add(match(INTTK));
        mainFuncDef.add(match(MAINTK));
        mainFuncDef.add(match(LPARENT));
        if (token.is(RPARENT)) {
            mainFuncDef.add(match(RPARENT));
        } else {
            notifyErrorListeners(mainFuncDef.getEndLineno(), MISSING_RPARENT);
        }
        mainFuncDef.add(parseBlockContext());

        return mainFuncDef;
    }

    private FuncTypeContext parseFuncTypeContext() {
        FuncTypeContext funcType = new FuncTypeContext();

        funcType.add(match(VOIDTK, INTTK, CHARTK));

        return funcType;
    }

    private FuncFParamsContext parseFuncFParamsContext() {
        FuncFParamsContext funcFParams = new FuncFParamsContext();

        funcFParams.add(parseFuncFParamContext());
        while (token.is(COMMA)) {
            funcFParams.add(match(COMMA));
            funcFParams.add(parseFuncFParamContext());
        }

        return funcFParams;
    }

    private FuncFParamContext parseFuncFParamContext() {
        FuncFParamContext funcFParam = new FuncFParamContext();

        funcFParam.add(parseBTypeContext());
        funcFParam.add(match(IDENFR));
        if (token.is(LBRACK)) {
            funcFParam.add(match(LBRACK));
            if (token.is(RBRACK)) {
                funcFParam.add(match(RBRACK));
            } else {
                notifyErrorListeners(funcFParam.getEndLineno(), MISSING_RBRACK);
            }
        }

        return funcFParam;
    }

    private BlockContext parseBlockContext() {
        BlockContext block = new BlockContext();

        block.add(match(LBRACE));
        // 试探 blockItem: 这样试探?
        //while (token.any(CONSTTK, INTTK, CHARTK, // 1) 试探 decl
        //        IDENFR, // 2) 试探 lVal
        //        IDENFR, STRCON, CHRCON, LPARENT, PLUS, MINU, NOT, // 3) 试探 exp
        //        SEMICN, // * exp 还可能是空的
        //        LBRACE, // 4) 试探 block
        //        IFTK, FORTK,
        //        BREAKTK, RETURNTK, CONTINUETK,
        //        GETINTTK, GETCHARTK, PRINTFTK)) {
        //    block.add(parseBlockItemContext());
        //}
        // 试探 blockItem: 或者这样试探?
        while (!token.is(RBRACE)) {
            block.add(parseBlockItemContext());
        }
        block.add(match(RBRACE));

        return block;
    }

    private BlockItemContext parseBlockItemContext() {
        BlockItemContext blockItem = new BlockItemContext();

        if (token.any(CONSTTK, INTTK, CHARTK)) {
            blockItem.add(parseDeclContext());
        } else {
            blockItem.add(parseStmtContext());
        }

        return blockItem;
    }

    private StmtContext parseStmtContext() {
        switch (token.getType()) {
            case LBRACE:
                return parseBlockStmtContext();
            case IFTK:
                return parseIfStmtContext();
            case FORTK:
                return parseForloopStmtContext();
            case BREAKTK:
                return parseBreakStmtContext();
            case CONTINUETK:
                return parseContinueStmtContext();
            case RETURNTK:
                return parseReturnStmtContext();
            case PRINTFTK:
                return parsePrintfStmtContext();
            default:
                // now --- peek1 --- peek2
                //           ↑
                //        nextindex
                // 接下来的第一个 token 是 IDENFR?
                //      1) 不是 ==> 一定是表达式语句
                //      2) 是, 再接下来?
                //          1) 是 ASSIGN ==> 一定是赋值语句
                //          2) 不是 LBRACK ==> 一定是表达式语句
                //          3) 是 LBRACK
                //                  一直读到非表达式构成元素
                //                  中间读到 ASSIGN 则为赋值语句, 否则为表达式语句
                //
                if (!token.is(IDENFR)) {
                    return parseExpStmtContext();
                } else {
                    if (peekNext(1).is(ASSIGN)) {
                        return parseAssignStmtContext();
                    } else if (!peekNext(1).is(LBRACK)) {
                        return parseExpStmtContext();
                    } else {
                        // 究竟是 id[巨长的表达式....] = ....;
                        // 还是   id[巨长的表达式...] ;
                        // 而且其中的';'可以省略, 其中的']'可能省略也可能嵌套出现
                        // 即不能简单凭借';'的有无来判断, 也不能简单凭借']'的有无和多寡来判断
                        ListIterator<Token> probeIterator = tokens.listIterator(iterator.nextIndex());
                        boolean hasAssign = false;
                        while (probeIterator.hasNext()) {
                            Token probeToken = probeIterator.next();
                            if (probeToken.is(ASSIGN)) {
                                hasAssign = true;
                            }
                            // 读到非表达式的元素为止?
                            if (!probeToken.any(IDENFR, LPARENT, RPARENT,
                                    INTCON, CHRCON,
                                    PLUS, MINU, NOT, MULT, DIV, MOD,
                                    LBRACK, RBRACK)) {
                                break;
                            }
                        }
                        return hasAssign ? parseAssignStmtContext() : parseExpStmtContext();
                    }
                }
        }
    }


    private AssignStmtContext parseAssignStmtContext() {
        AssignStmtContext assignStmt = new AssignStmtContext();

        assignStmt.add(parseLValContext());
        assignStmt.add(match(ASSIGN));
        if (token.any(GETINTTK, GETCHARTK)) {
            assignStmt.add(match(GETINTTK, GETCHARTK));
            assignStmt.add(match(LPARENT));
            if (token.is(RPARENT)) {
                assignStmt.add(match(RPARENT));
            } else {
                notifyErrorListeners(assignStmt.getEndLineno(), MISSING_RPARENT);
            }
        } else {
            assignStmt.add(parseExpContext());
        }

        if (token.is(SEMICN)) {
            assignStmt.add(match(SEMICN));
        } else {
            notifyErrorListeners(assignStmt.getEndLineno(), MISSING_SEMICOLON);
        }

        return assignStmt;
    }

    private ExpStmtContext parseExpStmtContext() {
        ExpStmtContext expStmt = new ExpStmtContext();

        // 试探 exp
        if (token.any(IDENFR, INTCON, CHRCON, LPARENT, PLUS, MINU, NOT)) {
            expStmt.add(parseExpContext());
        }
        if (token.is(SEMICN)) {
            expStmt.add(match(SEMICN));
        } else {
            notifyErrorListeners(expStmt.getEndLineno(), MISSING_SEMICOLON);
        }

        return expStmt;
    }

    private BlockStmtContext parseBlockStmtContext() {
        BlockStmtContext blockStmt = new BlockStmtContext();

        blockStmt.add(parseBlockContext());

        return blockStmt;
    }

    private IfStmtContext parseIfStmtContext() {
        IfStmtContext ifStmt = new IfStmtContext();

        ifStmt.add(match(IFTK));
        ifStmt.add(match(LPARENT));
        ifStmt.add(parseCondContext());
        if (token.is(RPARENT)) {
            ifStmt.add(match(RPARENT));
        } else {
            notifyErrorListeners(ifStmt.getEndLineno(), MISSING_RPARENT);
        }
        ifStmt.add(parseStmtContext());
        if (token.is(ELSETK)) {
            ifStmt.add(match(ELSETK));
            ifStmt.add(parseStmtContext());
        }

        return ifStmt;
    }

    private ForloopStmtContext parseForloopStmtContext() {
        ForloopStmtContext forloopStmt = new ForloopStmtContext();

        forloopStmt.add(match(FORTK));
        forloopStmt.add(match(LPARENT));
        // 试探 forStmt
        if (token.is(IDENFR)) {
            forloopStmt.add(parseForStmtContext());
        }
        forloopStmt.add(match(SEMICN));
        // 试探 cond
        if (token.any(IDENFR, INTCON, CHRCON, LPARENT, PLUS, MINU, NOT)) {
            forloopStmt.add(parseCondContext());
        }
        forloopStmt.add(match(SEMICN));
        // 试探 forStmt
        if (token.is(IDENFR)) {
            forloopStmt.add(parseForStmtContext());
        }
        if (token.is(RPARENT)) {
            forloopStmt.add(match(RPARENT));
        } else {
            notifyErrorListeners(forloopStmt.getEndLineno(), MISSING_RPARENT);
        }
        forloopStmt.add(parseStmtContext());

        return forloopStmt;
    }

    private BreakStmtContext parseBreakStmtContext() {
        BreakStmtContext breakStmt = new BreakStmtContext();

        breakStmt.add(match(BREAKTK));
        if (token.is(SEMICN)) {
            breakStmt.add(match(SEMICN));
        } else {
            notifyErrorListeners(breakStmt.getEndLineno(), MISSING_SEMICOLON);
        }

        return breakStmt;
    }

    private ContinueStmtContext parseContinueStmtContext() {
        ContinueStmtContext continueStmt = new ContinueStmtContext();

        continueStmt.add(match(CONTINUETK));
        if (token.is(SEMICN)) {
            continueStmt.add(match(SEMICN));
        } else {
            notifyErrorListeners(continueStmt.getEndLineno(), MISSING_SEMICOLON);
        }

        return continueStmt;
    }

    private ReturnStmtContext parseReturnStmtContext() {
        ReturnStmtContext returnStmt = new ReturnStmtContext();

        returnStmt.add(match(RETURNTK));
        // 试探 exp
        if (token.any(IDENFR, INTCON, CHRCON, LPARENT, PLUS, MINU, NOT)) {
            returnStmt.add(parseExpContext());
        }
        if (token.is(SEMICN)) {
            returnStmt.add(match(SEMICN));
        } else {
            notifyErrorListeners(returnStmt.getEndLineno(), MISSING_SEMICOLON);
        }

        return returnStmt;
    }

    private PrintfStmtContext parsePrintfStmtContext() {
        PrintfStmtContext printfStmt = new PrintfStmtContext();

        printfStmt.add(match(PRINTFTK));
        printfStmt.add(match(LPARENT));
        printfStmt.add(match(STRCON));
        while (token.is(COMMA)) {
            printfStmt.add(match(COMMA));
            printfStmt.add(parseExpContext());
        }
        if (token.is(RPARENT)) {
            printfStmt.add(match(RPARENT));
        } else {
            notifyErrorListeners(printfStmt.getEndLineno(), MISSING_RPARENT);
        }
        if (token.is(SEMICN)) {
            printfStmt.add(match(SEMICN));
        } else {
            notifyErrorListeners(printfStmt.getEndLineno(), MISSING_SEMICOLON);
        }

        return printfStmt;
    }

    private ForStmtContext parseForStmtContext() {
        ForStmtContext forStmt = new ForStmtContext();

        forStmt.add(parseLValContext());
        forStmt.add(match(ASSIGN));
        forStmt.add(parseExpContext());

        return forStmt;
    }

    private ExpContext parseExpContext() {
        ExpContext exp = new ExpContext();

        exp.add(parseAddExpContext());

        return exp;
    }


    private CondContext parseCondContext() {
        CondContext cond = new CondContext();

        cond.add(parseLOrExpContext());

        return cond;
    }

    private LValContext parseLValContext() {
        LValContext lVal = new LValContext();

        lVal.add(match(IDENFR));
        if (token.is(LBRACK)) {
            lVal.add(match(LBRACK));
            lVal.add(parseExpContext());
            if (token.is(RBRACK)) {
                lVal.add(match(RBRACK));
            } else {
                notifyErrorListeners(lVal.getEndLineno(), MISSING_RBRACK);
            }
        }

        return lVal;
    }

    private PrimaryExpContext parsePrimaryExpContext() {
        PrimaryExpContext primaryExp = new PrimaryExpContext();

        if (token.is(LPARENT)) {
            primaryExp.add(match(LPARENT));
            primaryExp.add(parseExpContext());
            if (token.is(RPARENT)) {
                primaryExp.add(match(RPARENT));
            } else {
                notifyErrorListeners(primaryExp.getEndLineno(), MISSING_RPARENT);
            }
        } else if (token.is(IDENFR)) {
            primaryExp.add(parseLValContext());
        } else if (token.is(INTCON)) {
            primaryExp.add(parseNumberContext());
        } else if (token.is(CHRCON)) {
            primaryExp.add(parseCharacterContext());
        }

        return primaryExp;
    }

    private NumberContext parseNumberContext() {
        NumberContext number = new NumberContext();

        number.add(match(INTCON));

        return number;
    }

    private CharacterContext parseCharacterContext() {
        CharacterContext character = new CharacterContext();

        character.add(match(CHRCON));

        return character;
    }

    private UnaryExpContext parseUnaryExpContext() {
        UnaryExpContext unaryExp = new UnaryExpContext();

        if (token.is(IDENFR) && peekNext(iterator, tokens, 1).is(LPARENT)) {
            unaryExp.add(match(IDENFR));
            unaryExp.add(match(LPARENT));
            // 试探 exp
            if (token.any(IDENFR, LPARENT, CHRCON, INTCON, PLUS, MINU, NOT)) {
                unaryExp.add(parseFuncRParamsContext());
            }
            if (token.is(RPARENT)) {
                unaryExp.add(match(RPARENT));
            } else {
                notifyErrorListeners(unaryExp.getEndLineno(), MISSING_RPARENT);
            }
        } else if (token.any(PLUS, MINU, NOT)) {
            unaryExp.add(parseUnaryOpContext());
            unaryExp.add(parseUnaryExpContext());
        } else {
            unaryExp.add(parsePrimaryExpContext());
        }

        return unaryExp;
    }

    private UnaryOpContext parseUnaryOpContext() {
        UnaryOpContext unaryOp = new UnaryOpContext();

        unaryOp.add(match(PLUS, MINU, NOT));

        return unaryOp;
    }

    private FuncRParamsContext parseFuncRParamsContext() {
        FuncRParamsContext funcRParams = new FuncRParamsContext();

        funcRParams.add(parseExpContext());
        while (token.is(COMMA)) {
            funcRParams.add(match(COMMA));
            funcRParams.add(parseExpContext());
        }

        return funcRParams;
    }

    private MulExpContext parseMulExpContext() {
        MulExpContext mulExp = new MulExpContext();

        mulExp.add(parseUnaryExpContext());
        while (token.any(MULT, DIV, MOD)) {
            TerminalContext op = match(MULT, DIV, MOD);
            UnaryExpContext right = parseUnaryExpContext();

            MulExpContext tmp = new MulExpContext();
            tmp.add(mulExp);
            tmp.add(op);
            tmp.add(right);
            mulExp = tmp;
        }

        return mulExp;
    }

    private AddExpContext parseAddExpContext() {
        AddExpContext addExp = new AddExpContext();

        addExp.add(parseMulExpContext());
        while (token.any(PLUS, MINU)) {
            TerminalContext op = match(PLUS, MINU);
            MulExpContext right = parseMulExpContext();

            AddExpContext tmp = new AddExpContext();
            tmp.add(addExp);
            tmp.add(op);
            tmp.add(right);
            addExp = tmp;
        }

        return addExp;
    }

    private RelExpContext parseRelExpContext() {
        RelExpContext relExp = new RelExpContext();
        relExp.add(parseAddExpContext());

        while (token.any(LSS, GRE, LEQ, GEQ)) {
            TerminalContext op = match(LSS, GRE, LEQ, GEQ);
            AddExpContext right = parseAddExpContext();

            RelExpContext tmp = new RelExpContext();
            tmp.add(relExp);
            tmp.add(op);
            tmp.add(right);
            relExp = tmp;
        }

        return relExp;
    }

    private EqExpContext parseEqExpContext() {
        EqExpContext eqExp = new EqExpContext();

        eqExp.add(parseRelExpContext());
        while (token.any(EQL, NEQ)) {
            TerminalContext op = match(EQL, NEQ);
            RelExpContext right = parseRelExpContext();

            EqExpContext tmp = new EqExpContext();
            tmp.add(eqExp);
            tmp.add(op);
            tmp.add(right);
            eqExp = tmp;
        }

        return eqExp;
    }

    private LAndExpContext parseLAndExpContext() {
        LAndExpContext lAndExp = new LAndExpContext();

        lAndExp.add(parseEqExpContext());
        while (token.is(AND)) {
            TerminalContext op = match(AND);
            EqExpContext right = parseEqExpContext();

            LAndExpContext tmp = new LAndExpContext();
            tmp.add(lAndExp);
            tmp.add(op);
            tmp.add(right);
            lAndExp = tmp;
        }

        return lAndExp;
    }

    private LOrExpContext parseLOrExpContext() {
        LOrExpContext lOrExp = new LOrExpContext();

        lOrExp.add(parseLAndExpContext());
        while (token.is(OR)) {
            TerminalContext op = match(OR);
            LAndExpContext right = parseLAndExpContext();

            LOrExpContext tmp = new LOrExpContext();
            tmp.add(lOrExp);
            tmp.add(op);
            tmp.add(right);
            lOrExp = tmp;
        }

        return lOrExp;
    }

    private ConstExpContext parseConstExpContext() {
        ConstExpContext constExp = new ConstExpContext();

        constExp.add(parseAddExpContext());

        return constExp;
    }

    private TerminalContext match(TokenType... type) {
        ASSERT(token.any(type), "mismatch token: " + token.getText() + " at line " + token.getLineno() + ", expected " + type[0].toString() + " or ...");
        TerminalContext r = new TerminalContext(token);
        if (iterator.hasNext()) {
            this.token = iterator.next();
        } else {
            this.token = null;
        }
        return r;
    }

    public void addErrorListener(ErrorListener listener) {
        errorListeners.add(listener);
    }

    private void notifyErrorListeners(int lineno, ErrorType errorType) {
        for (ErrorListener listener : errorListeners) {
            listener.onError(lineno, errorType);  // 通知所有监听者
        }
    }

    private Token peekNext(int k) {
        return peekNext(iterator, tokens, k);
    }

    public static <T> T peekNext(ListIterator<T> iterator, LinkedList<T> list, int k) {
        // 获取当前迭代器的索引
        int currentIndex = iterator.nextIndex();

        // 检查是否可以预览到第 k 个元素
        if (currentIndex + k - 1 < list.size()) {
            return list.get(currentIndex + k - 1); // 返回第 k 个元素
        } else {
            return null; // 如果没有足够的元素则返回 null
        }
    }
}
