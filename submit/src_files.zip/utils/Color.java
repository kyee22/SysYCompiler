/*
 * SysYCompiler: A Compiler for SysY.
 *
 * SysYCompiler is an individually developed course project
 * for Compiling Techniques @ School of Computer Science &
 * Engineering, Beihang University, Fall 2024.
 *
 * Copyright (C) 2024 Yixuan Kuang <kyee22@buaa.edu.cn>
 *
 * This file is part of SysYCompiler.
 */

package utils;

public enum Color {
    BRIGHT_CYAN, BRIGHT_RED, MAGENTA, BRIGHT_YELLOW, WHITE, BRIGHT_MAGENTA, BRIGHT_GREEN, BRIGHT_BLUE
}
